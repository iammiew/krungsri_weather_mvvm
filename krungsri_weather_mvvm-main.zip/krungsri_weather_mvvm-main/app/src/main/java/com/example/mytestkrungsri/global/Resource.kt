package com.example.mytestkrungsri.global

var TITLE_WEATHER = "WEATHER"
var metricType = "metric"
var imperialType = "imperial"
var defaultCity = "Bangkok"
var cloudsWeather = "clouds"
var rainWeather = "rain"