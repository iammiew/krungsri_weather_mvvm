package com.example.mytestkrungsri

import junit.framework.TestCase
import org.junit.Test

class WeatherViewModelTest : TestCase(){

    private lateinit var viewModel: WeatherViewModelT()

    @Test
    fun ss (){

    }
}